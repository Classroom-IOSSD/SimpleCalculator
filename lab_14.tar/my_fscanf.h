#ifdef MY_FSCANF_H
#define MY_FSCANF_H
#include <stdio.h>

void my_fscanf(FILE *fp, const char *format,...);

#endif /* !MY_FSCANF_H */
