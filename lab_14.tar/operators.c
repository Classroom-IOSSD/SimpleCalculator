#include "operators.h"

double add(double op1, double op2) {
	return op1+op2;
}
double minus(double op1, double op2) {
	return op1-op2;
}
double mul(double op1, double op2) {
	return op1*op2;
}

double div(double op1, double op2) {
	return op1/op2;
}

